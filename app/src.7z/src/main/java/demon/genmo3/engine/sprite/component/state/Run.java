package demon.genmo3.engine.sprite.component.state;

import demon.genmo3.engine.control.Keys;
import demon.genmo3.engine.sprite.component.StateMachine;

public class Run extends State
{
    public Run()
    {
        this.type = StateType.RUN;
        this.level = 0;
    }

    @Override
    public State tryTranslate(StateMachine stateMachine)
    {
        if (Keys.JUMP.use())
        {

        }
        if (Keys.LEFT.use())
        {

        }
        if (Keys.RIGHT.use())
        {

        }

        return this;
    }
}
