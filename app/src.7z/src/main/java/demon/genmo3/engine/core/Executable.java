package demon.genmo3.engine.core;

public interface Executable
{
    public void onUpdate();
}
