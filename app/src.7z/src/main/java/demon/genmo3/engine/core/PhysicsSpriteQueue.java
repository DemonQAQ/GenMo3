package demon.genmo3.engine.core;

import java.util.ArrayList;

import demon.genmo3.engine.physics.Gravity;
import demon.genmo3.engine.physics.Movable;

public class PhysicsSpriteQueue
{
    private static final ArrayList<Gravity> GRAVITY_LIST = new ArrayList<>();
    private static final ArrayList<Movable> MOVABLE_LIST = new ArrayList<>();

    public PhysicsSpriteQueue()
    {

    }

    public void onPhysics()
    {
        //处理重力影响
        gravity();
        //处理碰撞事件
        Movable[] m = MOVABLE_LIST.toArray(new Movable[0]);
        MOVABLE_LIST.forEach(e->
        {
            for (Movable movable : m)
            {
                if(e.intersect(movable))e.onIntersect(movable);
            }
        });
        //处理坐标变换
        MOVABLE_LIST.forEach(Movable::move);
    }

    private void gravity()
    {
        GRAVITY_LIST.forEach(e->{
            if (!e.isOnGround())
            {
                e.setYSpeed(e.getYSpeed()-Gravity.G);
            }
        });
    }



    public void add(Gravity e)
    {
        GRAVITY_LIST.add(e);
    }

    public void add(Movable e)
    {
        MOVABLE_LIST.add(e);
    }

    public <E> void add(E e)
    {
        if (e instanceof Gravity && e instanceof Movable) {
            GRAVITY_LIST.add((Gravity) e);
            MOVABLE_LIST.add((Movable) e);
        }
    }

    public void remove(Gravity e)
    {
        GRAVITY_LIST.remove(e);
    }

    public void remove(Movable e)
    {
        MOVABLE_LIST.remove(e);
    }

    public <E> void remove(E e)
    {
        if (e instanceof Gravity && e instanceof Movable) {
            GRAVITY_LIST.remove((Gravity) e);
            MOVABLE_LIST.remove((Movable) e);
        }
    }
}
