package demon.genmo3.engine.utils;

public class ValueUtils
{
    public static int SCREEN_WIDTH;
    public static int SCREEN_HEIGHT;

    public static void init(int screenWidth,int screenHeight)
    {
        SCREEN_WIDTH = screenWidth;
        SCREEN_HEIGHT = screenHeight;
    }
}
