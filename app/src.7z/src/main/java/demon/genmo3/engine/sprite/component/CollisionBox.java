package demon.genmo3.engine.sprite.component;


/*
 * 以一个矩形区域表示实体的体积
 * */
public class CollisionBox
{
    int x;
    int y;
    int width;
    int height;

    public CollisionBox(int x, int y, int width, int height)
    {
        setLocation(x, y);
        setArea(width, height);
    }

    public void setLocation(int x, int y)
    {
        this.x = x;
        this.y = y;
    }

    public void setArea(int width, int height)
    {
        this.width = width;
        this.height = height;
    }

    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }

    public boolean checkIntersect(CollisionBox e)
    {
        int maxLeft = 0;
        int maxTop = 0;
        int minRight = 0;
        int minBottom = 0;

        maxLeft = Math.max(this.x, e.x);
        maxTop = Math.max(this.x,e.x);
        minRight = Math.min(this.x + this.width, e.x + e.width);
        minBottom = Math.min(this.y + this.height, e.y + e.height);

        return maxLeft > minRight || maxTop > minBottom;
    }

    public boolean checkAboveIntersect()
    {
        return false;
    }
}
