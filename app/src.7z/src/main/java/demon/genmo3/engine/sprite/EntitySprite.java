package demon.genmo3.engine.sprite;

import android.graphics.Canvas;
import android.graphics.Paint;

import demon.genmo3.engine.physics.Gravity;
import demon.genmo3.engine.physics.Movable;
import demon.genmo3.engine.render.Drawable;
import demon.genmo3.engine.render.DynamicTexture;
import demon.genmo3.engine.sprite.component.Animations;
import demon.genmo3.engine.sprite.component.CollisionBox;
import demon.genmo3.engine.sprite.component.StateMachine;

/*
* 玩家实体的基本实现
* */
public class EntitySprite extends Sprite implements Gravity, Movable, Drawable
{
    private float xSpeed = 0;
    private float xAccelerate = 5;
    private float xSpeedMax = 20;
    private float ySpeed = 0;
    private float yAccelerate = 0;
    private float ySpeedMax = 20;
    private CollisionBox collisionBox;
    private Animations animations;
    private StateMachine stateMachine;
    private DynamicTexture texture;

    public EntitySprite(int x, int y)
    {
        setX(x);
        setY(y);
    }

    @Override
    protected void finalize() throws Throwable
    {
        super.finalize();
        stateMachine.destroy();
    }

    @Override
    public void onUpdate()
    {
        if (stateMachine.isTranslate())
        {
            texture = animations.get(stateMachine.getState());
        }
    }

    @Override
    public boolean isOnGround()
    {
        return stateMachine.isOnGround();
    }


    //处理x轴和y轴的移动逻辑
    @Override
    public void move()
    {

    }

    @Override
    public boolean intersect(Movable e)
    {
        return false;
    }

    @Override
    public void onIntersect(Movable e)
    {

    }

    @Override
    public void onDraw(Canvas canvas, Paint p)
    {
        canvas.drawBitmap(texture.getImg(stateMachine.getDirection()),getX(),getY(),p);
    }

    public float getXSpeed()
    {
        return xSpeed;
    }

    public void setXSpeed(float xSpeed)
    {
        this.xSpeed = xSpeed;
    }

    @Override
    public float getYSpeed()
    {
        return ySpeed;
    }

    @Override
    public void setYSpeed(float value)
    {
        this.ySpeed = value;
    }

    public float getXAccelerate()
    {
        return xAccelerate;
    }

    public void setXAccelerate(float xAccelerate)
    {
        this.xAccelerate = xAccelerate;
    }

    public float getYAccelerate()
    {
        return yAccelerate;
    }

    public void setYAccelerate(float yAccelerate)
    {
        this.yAccelerate = yAccelerate;
    }

    public int getXPoint()
    {
        return getX()+(texture.getWidth()/2);
    }

    public int getYPoint()
    {
        return getY()+(texture.getHeight()/2);
    }
}
