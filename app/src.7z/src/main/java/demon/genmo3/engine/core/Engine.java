package demon.genmo3.engine.core;

public interface Engine
{
    void update();
    void draw();
    void physics();
    void init();
}
