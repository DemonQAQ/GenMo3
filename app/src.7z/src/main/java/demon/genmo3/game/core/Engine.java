package demon.genmo3.game.core;

import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.NonNull;

import demon.genmo3.engine.core.GameEngine;

public class Engine extends GameEngine
{
    public Engine(SurfaceView surfaceView, SurfaceHolder holder)
    {
        super(surfaceView, holder);
    }

    @Override
    public void update()
    {
        super.update();
    }

    @Override
    public void physics()
    {
        super.physics();
    }

    @Override
    public void init()
    {
        super.init();
    }
}
