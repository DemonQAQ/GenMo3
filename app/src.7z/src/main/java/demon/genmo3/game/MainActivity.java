package demon.genmo3.game;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;
import android.widget.ImageButton;

import demon.genmo3.R;
import demon.genmo3.engine.control.ButtonListener;
import demon.genmo3.engine.control.KeyEvent;
import demon.genmo3.engine.utils.TextureUtils;
import demon.genmo3.game.core.Engine;

public class MainActivity extends AppCompatActivity
{
    private SurfaceView surfaceView;
    private SurfaceHolder surfaceHolder;
    private Resources resources;
    private Engine engine;

    private ImageButton attack;
    private ImageButton jump;
    private ImageButton left;
    private ImageButton right;
    private ImageButton skill1;
    private ImageButton skill2;
    private ImageButton skill3;
    private ImageButton skill4;
    private ImageButton item;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        appInit();
        gameInit();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void appInit()
    {
        //隐藏状态栏标题栏
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null)actionBar.hide();
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        //初始化按钮
        attack = findViewById(R.id.attack);
        jump = findViewById(R.id.jump);
        left = findViewById(R.id.left);
        right = findViewById(R.id.right);
        skill1 = findViewById(R.id.skill1);
        skill2 = findViewById(R.id.skill2);
        skill3 = findViewById(R.id.skill3);
        skill4 = findViewById(R.id.skill4);
        item = findViewById(R.id.item);

        attack.setOnTouchListener(new ButtonListener(KeyEvent.ATTACK));
        jump.setOnTouchListener(new ButtonListener(KeyEvent.JUMP));
        left.setOnTouchListener(new ButtonListener(KeyEvent.LEFT));
        right.setOnTouchListener(new ButtonListener(KeyEvent.RIGHT));
        skill1.setOnTouchListener(new ButtonListener(KeyEvent.SKILL1));
        skill2.setOnTouchListener(new ButtonListener(KeyEvent.SKILL2));
        skill3.setOnTouchListener(new ButtonListener(KeyEvent.SKILL3));
        skill4.setOnTouchListener(new ButtonListener(KeyEvent.SKILL4));
        item.setOnTouchListener(new ButtonListener(KeyEvent.ITEM));
    }

    private void gameInit()
    {
        resources = this.getResources();
        surfaceView = findViewById(R.id.surfaceview1);
        surfaceHolder = surfaceView.getHolder();
        TextureUtils.init(resources);
        //创建引擎部分
        engine = new Engine(surfaceView,surfaceHolder);
        surfaceHolder.addCallback(engine);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
    }

}